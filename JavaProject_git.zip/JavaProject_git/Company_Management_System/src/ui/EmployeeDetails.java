package ui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import operation.OperationEmpDetail;

public class EmployeeDetails extends JFrame {

	
	JButton button1;
	
	public EmployeeDetails() {
		setLayout(new FlowLayout());
		
		button1 = new JButton("Show Detail's");
		
		button1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new OperationEmpDetail().showData();
				
				
			}
		});
		
		add(button1);
		
		
		setVisible(true);
		setSize(400, 400);

	}
}
