package ui;

import java.awt.FlowLayout;

import javax.swing.JFrame;
import javax.swing.JLabel;

public class Utilities extends JFrame{

JLabel jLabel1, jLabel2, jLabel3;
	
	public Utilities() {
		setLayout(new FlowLayout());
		

		jLabel1 = new JLabel("Help");
		jLabel2 = new JLabel("Thought of the day");
		jLabel3 = new JLabel("Exit...");
		
		
		add(jLabel1);
		add(jLabel2);
		add(jLabel3);
		
		setVisible(true);
		setSize(400, 400);
	}
	
}
