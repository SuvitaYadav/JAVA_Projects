package ui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import operation.OperationAccount;
import operation.OperationEmpDetail;

public class Accounts extends JFrame {

	JLabel jLabel;
	JTextField field;
	JButton button1;
	
	public Accounts() {
		setLayout(new FlowLayout());
		
		jLabel = new JLabel("ID");
		field = new JTextField(20);
		
		Pojo pojo = new Pojo();
		button1 = new JButton("Search Detail's");
		
		button1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				int intid=Integer.parseInt(field.getText());
				new OperationAccount().SearchData(intid);
				//new OperationEmpDetail().showData();
				
				
			}
		});
		add(jLabel);
		add(field);
		add(button1);
		
		
		setVisible(true);
		setSize(400, 400);
	}
}
