package ui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class Home extends JFrame {

	JMenuBar bar;
	JMenu jMenu1, jMenu2, jMenu3, jMenu4;
	JMenuItem item1, item2, item3, item4;

	public Home() {
		
		setLayout(new FlowLayout());
		
		bar = new JMenuBar();
		bar.setBounds(0, 0, 400, 30);
		
		jMenu1 = new JMenu("Employee");
		jMenu2 = new JMenu("Employee details");
		jMenu3 = new JMenu("Account");
		jMenu4 = new JMenu("Utilities");
		
		item1 = new JMenuItem("Employee");
		
		item1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Employee();
				
			}
		});
		
		item2 = new JMenuItem("Employee details");
		
		item2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new EmployeeDetails();
				
			}
		});
		
		item3 = new JMenuItem("Account");
		
		item3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Accounts();
				
			}
		});
		
		item4 = new JMenuItem("Utilities");
		
		item4.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				new Utilities();
				
			}
		});
		
		add(bar);
		
		bar.add(jMenu1);
		bar.add(jMenu2);
		bar.add(jMenu3);
		bar.add(jMenu4);
		
		jMenu1.add(item1);
		jMenu2.add(item2);
		jMenu3.add(item3);
		jMenu4.add(item4);
		
		setVisible(true);
		setSize(400, 400);
	
	}
	
}
