package ui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import operation.OperationEmp;

public class Employee extends JFrame {

	JLabel jLabel1, jLabel2, jLabel3;
	JTextField field1, field2, field3;
	JButton button1, button2, button3;
	
	public Employee() {
	
		setLayout(new FlowLayout());
		
		jLabel1 = new JLabel("ID");
		jLabel2 = new JLabel("Name");
		jLabel3 = new JLabel("Salary");
		
		field1 = new JTextField(20);
		field2 = new JTextField(20);
		field3 = new JTextField(20);

		Pojo pojo = new Pojo();
		
		button1 = new JButton("Insert");
		button1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				pojo.setId(Integer.parseInt(field1.getText()));
				pojo.setName(field2.getText());
				pojo.setSal(Double.parseDouble(field3.getText()));

				new OperationEmp().InserData(pojo);
				System.out.println("Successfully data inserted");
				
			}
		});
		
		button2 = new JButton("Update");
		
		button2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				pojo.setId(Integer.parseInt(field1.getText()));
				pojo.setName(field2.getText());
				
				new OperationEmp().UpdateData(pojo);
				System.out.println("Successfully data updated");
				
			}
		});
		button3 = new JButton("Delete");
		
		button3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				pojo.setId(Integer.parseInt(field1.getText()));
				pojo.setName(field2.getText());
				pojo.setSal(Double.parseDouble(field3.getText()));

				new OperationEmp().DeleteData(pojo);
				System.out.println("Successfully data deleted");
			}
		});
		
		add(jLabel1);
		add(field1);
		add(jLabel2);
		add(field2);
		add(jLabel3);
		add(field3);
		
		add(button1);
		add(button2);
		add(button3);
		
		
		setVisible(true);
		setSize(400, 400);

		
	}
	
}
