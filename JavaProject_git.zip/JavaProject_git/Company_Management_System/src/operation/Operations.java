package operation;

import ui.Pojo;

public interface Operations {

	void InserData(Pojo pojo);
	
	void UpdateData(Pojo pojo);
	
	void DeleteData(Pojo pojo);
	
	void showData();
	
	void SearchData(int intid);
	
	
}
