package operation;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbconnection.GetConnection;
import ui.Pojo;

public class OperationAccount {

	public void SearchData(int intid) {
		
		try {
			PreparedStatement preparedStatement = GetConnection.getconnection()
					.prepareStatement("select sal from empinfo where id =?");
			
			preparedStatement.setInt(1, intid);
			ResultSet rs= preparedStatement.executeQuery();
			while (rs.next()) {
				System.out.println(rs.getDouble("sal"));
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}
