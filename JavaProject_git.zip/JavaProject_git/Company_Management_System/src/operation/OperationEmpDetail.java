package operation;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbconnection.GetConnection;
import ui.Pojo;

public class OperationEmpDetail implements Operations {

	@Override
	public void InserData(Pojo pojo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void UpdateData(Pojo pojo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void DeleteData(Pojo pojo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void showData() {
		try {
			ResultSet resultSet = GetConnection.getconnection().prepareStatement("select * from empinfo").executeQuery();
		
			while (resultSet.next()) {
				System.out.println(resultSet.getInt(1));
				System.out.println(resultSet.getString(2));
				System.out.println(resultSet.getDouble(3));

			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
		public void SearchData() {
			Pojo pojo = new Pojo();
			try {
				PreparedStatement preparedStatement = GetConnection.getconnection().prepareStatement("search empinfo set nsal = ? where id =?");
				
				preparedStatement.setInt(2, pojo.getId());
				preparedStatement.setString(1, pojo.getName());
				
				
				preparedStatement.executeUpdate();
				
			
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			
		}	
	

		@Override
		public void SearchData(int intid) {
			// TODO Auto-generated method stub
			
		}

		
}
