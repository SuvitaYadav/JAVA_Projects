package operation;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import dbconnection.GetConnection;
import ui.Pojo;

public class OperationEmp implements Operations {

	@Override
	public void InserData(Pojo pojo) {
		
		try {
			PreparedStatement preparedStatement = GetConnection.getconnection().prepareStatement("Insert into empinfo values(?,?,?)");
			
			preparedStatement.setInt(1, pojo.getId());
			preparedStatement.setString(2, pojo.getName());
			preparedStatement.setDouble(3, pojo.getSal());
			
			
			preparedStatement.executeUpdate();
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
	}

	@Override
	public void UpdateData(Pojo pojo) {
		try {
			PreparedStatement preparedStatement = GetConnection.getconnection().prepareStatement("Update empinfo set name = ? where id =?");
			
			preparedStatement.setInt(2, pojo.getId());
			preparedStatement.setString(1, pojo.getName());
			
			
			preparedStatement.executeUpdate();
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void DeleteData(Pojo pojo) {
		try {
			PreparedStatement preparedStatement = GetConnection.getconnection().prepareStatement("Delete from empinfo where id = ?");
			
			preparedStatement.setInt(1, pojo.getId());
				
			preparedStatement.executeUpdate();
			
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void showData() {
		try {
			ResultSet resultSet = GetConnection.getconnection().prepareStatement("select * from empinfo").executeQuery();
		
			while (resultSet.next()) {
				System.out.println(resultSet.getInt(1));
				System.out.println(resultSet.getString(2));
				System.out.println(resultSet.getDouble(3));

			}
		
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
	}

	@Override
	public void SearchData(int intid) {
		// TODO Auto-generated method stub
		
	}

}
