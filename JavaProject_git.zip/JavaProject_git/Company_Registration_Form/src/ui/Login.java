package ui;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

import dbconnection.GetConnection;

public class Login extends JFrame {

	JLabel jLabel1, jLabel2, jLabel3, jLabel4, jLabel5;
	JTextField field1,  field2, field3, field4, field5;
	JButton button1, button2, button3;
	
	public Login() {
		setLayout(new FlowLayout());
		
		jLabel1 = new JLabel("NAME");
		jLabel2 = new JLabel("CONTACT");
		jLabel3 = new JLabel("GENDER");
		jLabel4 = new JLabel("COMMENT");
		jLabel5 = new JLabel("CITY");
		field1 = new JTextField(20);
		field2 = new JTextField(20);
		field3 = new JTextField(20);
		field4 = new JTextField(20);
		field5 = new JTextField(20);
		
		button1 = new JButton("Submit");
		
		button1.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				try {
					ResultSet resultSet = GetConnection.getconnection().prepareStatement("select * from ui1").executeQuery() ;
				
					resultSet.next();
					
					System.out.println("Loged in..........");
					
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}		
			}
		});
		
		
		button2 = new JButton("Discard");
		
		button2.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				System.out.println("Data Discard");
				
			}
		});
		
		button3 = new JButton("Reset");
		
		button3.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				field1.setText("");
				field2.setText("");
				field3.setText("");
				field4.setText("");
				field5.setText("");
				System.out.println("Reset");
				
			}
		});
		
		
		
		add(jLabel1);
		add(field1);
		add(jLabel2);
		add(field2);
		add(jLabel3);
		add(field3);
		add(jLabel4);
		add(field4);
		add(jLabel5);
		add(field5);
		
		add(button1);
		add(button2);
		add(button3);
		
		setVisible(true);
		setSize(400, 400);
	}
	
	public static void main(String[] args) {
		 new Login();
	}
}
